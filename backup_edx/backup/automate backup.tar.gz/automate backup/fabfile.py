from fabric.api import *


def backup():
    local('fab host_to_backup get_backup')
    local('fab host_to_restore restore_backup')


def host_to_backup():
    env.hosts = ['ubuntu@34.227.148.187']
    env.key_filename = '~/projetos/backup/edx-teste.pem'


def get_backup():
    run('sudo docker exec trustcode-edx rm -R /edx/app/edxapp/edx-platform/backup')

    run('sudo docker exec trustcode-edx mongodump -d edxapp -o /edx/app/edxapp/edx-platform/backup')

    run('sudo docker exec trustcode-edx rm backup.tar.gz')

    run('sudo docker exec trustcode-edx tar -czvf backup.tar.gz backup')

    run('sudo docker cp trustcode-edx:/edx/app/edxapp/edx-platform/backup.tar.gz ~/backup.tar.gz')

    get('~/backup.tar.gz', '~/backup.tar.gz')


def host_to_restore():
    env.hosts = ['ubuntu@54.164.167.243']
    env.key_filename = '~/projetos/backup/edx-teste.pem'


def restore_backup():
    put('~/backup.tar.gz', '/home/ubuntu/backup.tar.gz', use_sudo=True)

    run('sudo docker exec trustcode-edx rm -R /edx/app/edxapp/edx-platform/backup.tar.gz')

    run('sudo docker cp /home/ubuntu/backup.tar.gz trustcode-edx:/edx/app/edxapp/edx-platform/backup.tar.gz')

    run('sudo docker exec trustcode-edx rm -R /edx/app/edxapp/edx-platform/backup')

    run('sudo docker exec trustcode-edx tar -vzxf /edx/app/edxapp/edx-platform/backup.tar.gz')

    run('sudo docker exec trustcode-edx mongorestore --drop /edx/app/edxapp/edx-platform/backup')
