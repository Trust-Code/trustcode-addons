#! /bin/bash

cd Transferências
ssh -i "edx-teste.pem" ubuntu@34.227.148.187

pwd
